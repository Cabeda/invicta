"""Reduced geometry diagnostic; not original-demand replay or a transport proposal."""
import json,sys,xml.etree.ElementTree as E
from pathlib import Path
import libsumo as s,sumo
sys.path.insert(0,'prototypes/line-701/full')
from trial_evidence import load_trial,sha256
from native_runner import context
source=Path('.cache/701-optimisation/trials/v5-moderate-priority-mapped-s17')
e=load_trial(source,model='.cache/701-optimisation/model-v5')
e.payload('network.net.xml')
state=E.fromstring(e.payload('final-state.xml'));routes={r.get('id'):r.get('edges').split() for r in state.findall('route')}
vehicle_rows={r.get('id'):r for r in state.findall('vehicle')}
root=E.fromstring(e.payload('routes.rou.xml'));types={r.get('id'):r for r in root.findall('vType')}
actors={}
for label,ident,edge in [('major','background_14_176','1569557888#0'),('minor','crossing_14_109','-1569557889')]:
 v=vehicle_rows[ident];route=routes[v.get('route')];index=int(v.get('state').split()[2]);assert route[index]==edge
 actors[label]={'source_id':ident,'type':v.get('type'),'path':route[max(0,index-2):index+5]}
folder=Path('.cache/701-followup/minimal-junction-sorted');folder.mkdir(exist_ok=False)
results=[]
for offset in [-5,0,5,10]:
 case=folder/str(offset);case.mkdir();xml=E.Element('routes')
 for ident in sorted({a['type'] for a in actors.values()}):xml.append(types[ident])
 for label,actor in actors.items():
  v=E.SubElement(xml,'vehicle',id=label,type=actor['type'],depart=str(20+(offset if label=='minor' else 0)),departLane='best',departPos='0',departSpeed='0')
  E.SubElement(v,'route',edges=' '.join(actor['path']))
 events=xml.findall('vehicle')
 for event in events:xml.remove(event)
 xml.extend(sorted(events,key=lambda row:float(row.get('depart'))))
 E.ElementTree(xml).write(case/'routes.rou.xml',encoding='utf-8',xml_declaration=True)
 cmd=[str(Path(sumo.SUMO_HOME)/'bin/sumo'),'--net-file',str(source/'network.net.xml'),'--route-files',str(case/'routes.rou.xml'),'--begin','0','--end','300','--seed','17','--time-to-teleport','-1','--no-warnings','true','--no-step-log','true','--duration-log.disable','true','--xml-validation','never','--collision-output',str(case/'collisions.xml')]
 s.start(cmd);arrived=set();departed=set();last=[]
 try:
  while s.simulation.getTime()<300 and s.simulation.getMinExpectedNumber()>0:
   s.simulationStep();arrived.update(s.simulation.getArrivedIDList());departed.update(s.simulation.getDepartedIDList())
  last=[{'actor':v,'context':context(s,v)} for v in s.vehicle.getIDList()]
  end=s.simulation.getTime()
 finally:s.close()
 assert departed=={'major','minor'}, 'Native input omitted a requested actor'
 result={'departed':sorted(departed),'minor_departure_offset_seconds':offset,'end':end,'completed':sorted(arrived),'unfinished_context':last,'collision_records':len(E.parse(case/'collisions.xml').getroot())}
 (case/'result.json').write_text(json.dumps(result,indent=2)+'\n');results.append(result)
 print(json.dumps({'offset':offset,'completed':sorted(arrived),'active':len(last),'end':end}),flush=True)
report={'schema':'invicta.reduced-geometry-diagnostic.v1','source':e.verified_identity(),'actors':actors,'cases':results,'full_service_compliance':False,'field_validated':False,'limitations':['Only two vehicles and a local route suffix are represented; boundary conditions and demand differ from the original execution.','This can investigate intrinsic geometry behavior but cannot qualify a transport proposal or prove the original queue cause.']}
(folder/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
