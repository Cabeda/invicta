"""Fresh two-vehicle geometry diagnostic; no original-demand/service claim."""
import json,sys,time,xml.etree.ElementTree as E
from pathlib import Path
import libsumo as sim,sumo
sys.path.insert(0,'prototypes/line-701/full')
from trial_evidence import load_trial,sha256
from native_runner import context
e=load_trial('prototypes/line-701/full/priority-search.json','v5-moderate-priority-mapped-s17')
inputs=Path('.cache/701-queue-onset/final-geometry')
assert (inputs/'network.net.xml').read_bytes()==e.payload('network.net.xml')
state=E.fromstring(e.payload('final-state.xml'));routes={r.get('id'):r.get('edges').split() for r in state.findall('route')}
vehicles={r.get('id'):r for r in state.findall('vehicle')}
original=E.fromstring(e.payload('routes.rou.xml'));types={r.get('id'):r for r in original.findall('vType')}
ids=['crossing_14_109','crossing_14_33'];actors={}
for ident in ids:
    v=vehicles[ident];path=routes[v.get('route')];i=int(v.get('state').split()[2])
    actors[ident]={'type':v.get('type'),'path':path[max(0,i-2):i+5]}
folder=Path('.cache/701-queue-onset/fresh-crossing-pair');folder.mkdir(exist_ok=False)
results=[];started=time.monotonic()
for offset in range(-10,11):
    assert time.monotonic()-started<120,'diagnostic sweep budget exceeded'
    case=folder/str(offset);case.mkdir();xml=E.Element('routes')
    for ident in sorted({a['type'] for a in actors.values()}):xml.append(types[ident])
    events=[]
    for ident,a in actors.items():
        v=E.Element('vehicle',id=ident,type=a['type'],depart=str(20+(offset if ident==ids[1] else 0)),
            departLane='best',departPos='0',departSpeed='0')
        E.SubElement(v,'route',edges=' '.join(a['path']));events.append(v)
    xml.extend(sorted(events,key=lambda r:float(r.get('depart'))))
    E.ElementTree(xml).write(case/'routes.rou.xml',encoding='utf-8',xml_declaration=True)
    command=[str(Path(sumo.SUMO_HOME)/'bin/sumo'),'--net-file',str(inputs/'network.net.xml'),
        '--route-files',str(case/'routes.rou.xml'),'--begin','0','--end','180','--seed','17',
        '--time-to-teleport','-1','--no-warnings','true','--no-step-log','true','--duration-log.disable','true',
        '--xml-validation','never','--collision-output',str(case/'collisions.xml')]
    sim.start(command);departed=set();arrived=set();trace=[]
    try:
        while sim.simulation.getTime()<180 and sim.simulation.getMinExpectedNumber()>0:
            sim.simulationStep();departed.update(sim.simulation.getDepartedIDList());arrived.update(sim.simulation.getArrivedIDList())
            trace.append({'time':sim.simulation.getTime(),'vehicles':[
                {'id':v,'lane':sim.vehicle.getLaneID(v),'position':sim.vehicle.getLanePosition(v),
                 'speed':sim.vehicle.getSpeed(v),'waiting':sim.vehicle.getWaitingTime(v)} for v in sim.vehicle.getIDList()]})
        last={v:{'lane':sim.vehicle.getLaneID(v),'waiting':sim.vehicle.getWaitingTime(v),
                 'position':sim.vehicle.getPosition(v),'leader':sim.vehicle.getLeader(v,200)} for v in sim.vehicle.getIDList()}
        end=sim.simulation.getTime()
    finally:sim.close()
    assert departed==set(ids),'A requested actor was not inserted'
    result={'offset':offset,'departed':sorted(departed),'arrived':sorted(arrived),'end':end,'unfinished':last,
        'collisions':len(E.parse(case/'collisions.xml').getroot())}
    (case/'trace.json').write_text(json.dumps(trace,indent=2)+'\n')
    (case/'result.json').write_text(json.dumps(result,indent=2)+'\n');results.append(result)
    print(json.dumps(result),flush=True)
report={'source':e.verified_identity(),'actors':actors,'cases':results,'harness_sha256':sha256(Path(__file__).read_bytes()),
    'network_sha256':sha256((inputs/'network.net.xml').read_bytes()),'full_service_compliance':False,
    'full_original_demand_preserved':False,'original_continuation_verified':False,'field_validated':False}
(folder/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
(folder/'harness.py').write_bytes(Path(__file__).read_bytes())
