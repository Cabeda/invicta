"""Bounded snapshot analogue; removing an actor is not a transport intervention."""
import argparse, json, sys, time, xml.etree.ElementTree as ET
from pathlib import Path
import libsumo as sim, sumo
sys.path.insert(0, 'prototypes/line-701/full')
from trial_evidence import load_trial, sha256
from native_runner import context

p=argparse.ArgumentParser()
p.add_argument('--case', required=True)
p.add_argument('--remove', action='append', default=[])
p.add_argument('--seconds', type=int, default=30)
args=p.parse_args()
assert 1 <= args.seconds <= 120
e=load_trial('prototypes/line-701/full/priority-search.json','v5-moderate-priority-mapped-s17')
inputs=Path('.cache/701-queue-onset/final-geometry')
names=['network.net.xml','routes.rou.xml','additional.add.xml','final-state.xml']
for name in names:assert (inputs/name).read_bytes()==e.payload(name)
folder=Path('.cache/701-queue-onset/actor-probes')/args.case
folder.mkdir(parents=True,exist_ok=False)
command=[str(Path(sumo.SUMO_HOME)/'bin/sumo'),'--net-file',str(inputs/'network.net.xml'),
    '--route-files',str(inputs/'routes.rou.xml'),'--additional-files',str(inputs/'additional.add.xml'),
    '--load-state',str(inputs/'final-state.xml'),'--begin','99299','--end',str(99299+args.seconds),
    '--seed','17','--time-to-teleport','-1','--time-to-teleport.ride','-1','--no-warnings','true',
    '--no-step-log','true','--duration-log.disable','true','--xml-validation','never',
    '--collision-output',str(folder/'collisions.xml')]
started=time.monotonic();sim.start(command)
watched=['background_14_176','crossing_14_109','bicycle_14_23','crossing_14_33','background_14_493','d1_bus_36','d0_bus_29']
rows=[]
def states():
    active=set(sim.vehicle.getIDList());result={}
    for v in watched:
        if v not in active:continue
        result[v]={'distance':sim.vehicle.getDistance(v),'lane':sim.vehicle.getLaneID(v),
            'position':sim.vehicle.getPosition(v),'speed':sim.vehicle.getSpeed(v),
            'waiting':sim.vehicle.getWaitingTime(v),'leader':sim.vehicle.getLeader(v,200),
            'next_links':sim.vehicle.getNextLinks(v),'junction_foes':[str(x) for x in sim.vehicle.getJunctionFoes(v,100)]}
    return result
try:
    before=states()
    initial_hash=sha256(json.dumps([(v,sim.vehicle.getLaneID(v),sim.vehicle.getLanePosition(v),
        sim.vehicle.getSpeed(v),sim.vehicle.getWaitingTime(v),sim.vehicle.getRoute(v))
        for v in sorted(sim.vehicle.getIDList())]).encode())
    for ident in args.remove:
        assert ident in sim.vehicle.getIDList()
        sim.vehicle.remove(ident)
    for i in range(args.seconds):
        assert time.monotonic()-started<120,'native budget exceeded'
        sim.simulationStep();rows.append({'time':sim.simulation.getTime(),'vehicles':states()})
    after=sim.simulation.getTime()
finally:sim.close()
(folder/'trace.json').write_text(json.dumps({'before':before,'rows':rows},indent=2)+'\n')
movement={v:round(rows[-1]['vehicles'][v]['distance']-data['distance'],6)
    for v,data in before.items() if v in rows[-1]['vehicles']}
report={'role':'snapshot_actor_removal_mechanism','source':e.verified_identity(),
    'initial_state_sha256':initial_hash,'removed':args.remove,'begin':99299,'end':after,
    'seconds':args.seconds,'movement_metres':movement,'collisions':len(ET.parse(folder/'collisions.xml').getroot()),
    'command':command,'input_hashes':{n:sha256((inputs/n).read_bytes()) for n in names},
    'harness_sha256':sha256(Path(__file__).read_bytes()),
    'trace_sha256':sha256((folder/'trace.json').read_bytes()),'full_service_compliance':False,
    'original_continuation_verified':False,'controller_state_restored':False,
    'full_original_demand_preserved':not bool(args.remove),'field_validated':False,
    'native_elapsed_seconds':time.monotonic()-started}
(folder/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'case':args.case,'removed':args.remove,'movement':movement,'collisions':report['collisions']}))
